<?php
//require BASE_PATH . '/app/sts/config.php';

echo "<a href='/exemplomvc/new' class='btn btn-success pull-right'>Add New Post</a>";