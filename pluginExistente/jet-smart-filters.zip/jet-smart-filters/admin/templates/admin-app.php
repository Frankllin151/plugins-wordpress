<?php
/**
 * Admin App template
 */
?>
<div id="jet-smart-filters-admin-app">
	<?php include jet_smart_filters()->plugin_path( 'admin/templates/preloader.php' ); ?>
</div>
